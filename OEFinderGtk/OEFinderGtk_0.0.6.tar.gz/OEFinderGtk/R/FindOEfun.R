#' @title Identify genes with ordering effects
#' @usage FindOEfun(Data, Group = NULL, Poly = 2, Nchunk = 8, Sigcut = 0.01, MeanLOD=1,
#'    Plot = FALSE, NumPlot = NULL, numNullgenes=10000, numPermu=10,
#'		  Seed=1, mfrow=c(5,4), twoside=FALSE)
#' @param Data Input data matrix (normalized)
#' @param Group Cell group indicator. If it is NULL, samples will be grouped into Nchunk groups
#' @param Poly Degree in polynomial fitting. 
#' @param Nchunk Number of chunks to perform the ANOVA
#' @param Sigcut Permutation p-value cutoff to define the genes with ordering effects
#' @param MeanLOD Lower limit of detection. Genes with mean < LOD will not be tested
#' @param Plot Whether generate plots
#' @param NumPlot Number of top genes to plot. If not specified, all genes with p value < cutoff will be plotted
#' @param numNullgenes Number of permuted genes to consider when estimating the null distribution
#' @param numPermu Number of cell permutation to perform
#' @param Seed seed
#' @param mfrow graphical parameter mfrow.
#' @param twoside whether perform two sided test on coefficient
#' @author Ning Leng
#' @details 
#' one sided p value from
#' http://www.montefiore.ulg.ac.be/~kvansteen/GBIO0009-1/ac20092010/Class8/Using%20R%20for%20linear%20regression.pdf
#' @return Sig: list of significant genes; Allp: p values for all genes;
#' Allpsort: p values for all genes (sorted); AdjustedData: data set with OE genes adjusted;
#' CleanedData: data set with OE genes removed; Statistics: observed aggregate statistics;
#' nullVector: aggregated statistics from permuted genes

FindOEfun<-
function (Data, Group = NULL, Poly = 2, Nchunk = 8, Sigcut = 0.01, MeanLOD=1,
    Plot = FALSE, NumPlot = NULL, numNullgenes=10000, numPermu=10,
	Seed=1, mfrow=c(5,4), twoside = FALSE)
{
    set.seed(Seed)
    
    # rescale here
    DataIn <- Data
	if(min(DataIn)<0)stop("Error: exist values < 0!")
    DataIn1 <- DataIn[which(rowMeans(DataIn)> MeanLOD & apply(DataIn,1,sd)>0),]
    cat(paste("\n Removed genes with mean smaller or equal to", MeanLOD, "\n"))
    DataMean <- apply(DataIn1,1,mean)
    DataSD <- apply(DataIn1,1,sd)
    Data <- (DataIn1-DataMean)/DataSD
    	
    
    Ncol <- ncol(Data)
    if (is.null(Group)) {
        Col <- rainbow(Nchunk)
        V_B <- rep(1:Nchunk, each = ceiling(Ncol/Nchunk))[1:Ncol]
        ColV_B <- rep(Col, each = ceiling(Ncol/Nchunk))[1:Ncol]
        Group <- as.factor(V_B)
    }
    else {
        if (!is.factor(Group))
        Group <- factor(Group)
        Nchunk <- nlevels(Group)
        Col <- rainbow(Nchunk)
        names(Col) <- levels(Group)
        V_B <- Group
        ColV_B <- Col[Group]
    }
    ## aggregate statistics on original data
    DataUse <- Data
    Datasort <- DataUse[, order(Group)]
    Fac <- as.numeric(factor(Group[order(Group)]))
    Aggr <- t(sapply(1:nrow(Datasort), function(i)PolyEach(Datasort[i, ], Fac , Poly, twoside=twoside)))
    rownames(Aggr) <- rownames(Datasort)
    colnames(Aggr) <- c("p2nd","coef2nd","coef1","r2","adjr2", "beta",
	"onesidep","ssall","ssr","ssreg","F","fpval","aggrstat")

    ## Permute data
    if(numNullgenes/numPermu > nrow(Data)) numPermu <- ceiling(numNullgenes/nrow(Data))
    set.seed(Seed)
    PermList <- sapply(1:numPermu,function(i)Datasort[,sample(1:Ncol,Ncol)],simplify=F)
    PermuMatAll <- do.call(rbind, PermList)
    set.seed(Seed)
    PermuMat <- PermuMatAll[sample(1:nrow(PermuMatAll), numNullgenes),]
    PermuAgg <- sapply(1:nrow(PermuMat), function(i)PolyEach(PermuMat[i, ], Fac , Poly, twoside=twoside)["aggrstat"])


	# empirical p value    
	AggrV <- Aggr[,"aggrstat"]
	Aggrp <- sapply(1:length(AggrV), function(i) sum(PermuAgg >= AggrV[i])/length(PermuAgg))
	names(Aggrp)=names(AggrV)
	AggrpS <- sort(Aggrp)
	Sig <- AggrpS[which(AggrpS<=Sigcut)]
        Allp <- Aggrp 
	Allpsort <- AggrpS  

	# Adj
	Po <- poly(Fac, Poly)
	coe2 <- Aggr[,"coef2nd"]
	Toadj <- outer(coe2, Po[,2])
	coe1 <- Aggr[,"coef1"]
	Toadj1 <- outer(coe1, Po[,1])
	rownames(Toadj) <- rownames(Datasort)
	if(length(Sig)>0){
	Dataadj <- Datasort
	#Dataadj[names(Sig),] <-  Dataadj[names(Sig),]-Toadj[names(Sig),] 
	Datarm <- Datasort[setdiff(rownames(Datasort),names(Sig)),]
}
	else{
	Dataadj <- Datasort
	Datarm <- Datasort
}

	# original scale
	DataadjTran <- Dataadj*DataSD + DataMean
	DataadjTran[names(Sig),] <-  outer(DataMean[names(Sig)], rep(1,Ncol) )
	DatarmTran <- Datarm * DataSD[setdiff(rownames(Datasort),names(Sig))] + DataMean[setdiff(rownames(Datasort),names(Sig))]
        

	if(Plot==TRUE){
                if(is.null(NumPlot))NumPlot=length(Sig)
								if(NumPlot>0){
                par(mfrow=mfrow)
                for(i in 1:NumPlot){
								tmpname=names(Allpsort)[i]	
                plot(1:Ncol,
                      DataIn[tmpname, order(Group)],
                       main=paste0(
                        tmpname," pval ",round(Allpsort[tmpname],4)),
                         ylab="Normalized Expression",xlab="cell", col=ColV_B)
        }
}}

	Out=list(Sig=Sig, Allp=Allp, Allpsort=Allpsort, AdjustedData=DataadjTran,
	CleanedData=DatarmTran, Statistics=Aggr, nullVector=PermuAgg)
}


#PolyEach <- function(X, V, Poly){
#        Po <- poly(V, Poly)
#	aa <- lm(X ~ Po)
#        bb <- summary(aa)
#        coe <- coefficients(bb)
#        # one side p
#        onesd <- pt(coe[3,3],aa$df.residual,lower.tail=FALSE)
#        # SS
#        ssall <- sum((X-mean(X))^2)
#        ssr <- sum(aa$residuals^2)
#        ssreg <- ssall-ssr
#        fstat <- bb$fstatistic
#        fp <- pf(fstat[1],fstat[2],fstat[3],lower.tail=FALSE)
#        out <- c(coe[3, 4],coe[3,1], coe[2,1],
#                bb$r.squared, bb$adj.r.squared,
#                coe[3,3],onesd, ssall, ssr, ssreg,
#                bb$fstatistic[1],fp, -log(onesd)-log(fp))
#        names(out) <- c("p2nd","coef2nd","coef1","r2","adjr2", "beta",
#	"onesidep","ssall","ssr","ssreg","F","fpval","aggrstat")
#	out
#} 


