#' @title Fit polynomial regression
#' @usage PolyEach(X, V, Poly), twoside=FALSE 
#' @param X Input data vector
#' @param V Cell group indicator
#' @param Poly Degree in polynomial fitting.
#' @param twoside whether perform two sided test on coefficient
#' @author Ning Leng
#' @details 
#' one sided p value from
#' http://www.montefiore.ulg.ac.be/~kvansteen/GBIO0009-1/ac20092010/Class8/Using%20R%20for%20linear%20regression.pdf
#' @return a vector of statistics


PolyEach <- function(X, V, Poly, twoside=FALSE){
        Po <- poly(V, Poly)
				aa <- lm(X ~ Po)
        bb <- summary(aa)
        coe <- coefficients(bb)
        # one side p
        onesd <- pt(coe[3,3],aa$df.residual,lower.tail=FALSE)
				if(twoside) onesd <- 2*pt(-abs(coe[3,3]),aa$df.residual)
        # SS
        ssall <- sum((X-mean(X))^2)
        ssr <- sum(aa$residuals^2)
        ssreg <- ssall-ssr
        fstat <- bb$fstatistic
        fp <- pf(fstat[1],fstat[2],fstat[3],lower.tail=FALSE)
        out <- c(coe[3, 4],coe[3,1], coe[2,1],
                bb$r.squared, bb$adj.r.squared,
                coe[3,3],onesd, ssall, ssr, ssreg,
                bb$fstatistic[1],fp, -log(onesd)-log(fp))
        names(out) <- c("p2nd","coef2nd","coef1","r2","adjr2", "beta",
	"onesidep","ssall","ssr","ssreg","F","fpval","aggrstat")
	out
} 


